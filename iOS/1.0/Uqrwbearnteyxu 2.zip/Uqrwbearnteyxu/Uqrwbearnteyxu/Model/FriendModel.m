//
//  FriendModel.m
//  Uqrwbearnteyxu
//
//  Created by Developer on 11/01/16.
//  Copyright © 2016 Rahul N. Mane. All rights reserved.
//

#import "FriendModel.h"

@implementation FriendModel

@end
