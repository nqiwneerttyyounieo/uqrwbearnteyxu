//
//  VIewUtility.h
//  Uqrwbearnteyxu
//
//  Created by Rahul N. Mane on 06/12/15.
//  Copyright © 2015 Rahul N. Mane. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface VIewUtility : NSObject

+(void)addHexagoneShapeMaskFor:(UIView *)viewObj;

@end
