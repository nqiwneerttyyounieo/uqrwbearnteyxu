//
//  NSNull+JSON.h
//  WCI
//
//  Created by Rahul N. Mane on 19/06/14.
//  Copyright (c) 2014 Rahul N. Mane. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSNull (JSON)

@end
