//
//  WebServiceFramework.h
//  WebServiceFramework
//
//  Created by Sweety Singh on 8/28/15.
//  Copyright (c) 2015 Perennial Systems. All rights reserved.
//

#import "UserWebServiceClient.h"

#import "Response.h"
