//
//  Constants.h
//  Uqrwbearnteyxu
//
//  Created by Rahul N. Mane on 12/12/15.
//  Copyright © 2015 Rahul N. Mane. All rights reserved.
//

#ifndef Constants_h
#define Constants_h


#define segueMakeProfile @"segueMakeProfile"



#endif /* Constants_h */
