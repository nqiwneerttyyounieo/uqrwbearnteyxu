//
//  FriendProfileTableViewCell.h
//  Uqrwbearnteyxu
//
//  Created by Developer on 06/01/16.
//  Copyright © 2016 Rahul N. Mane. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FriendProfileTableViewCell : UITableViewCell

@end
