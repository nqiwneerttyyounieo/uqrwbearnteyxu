//
//  FriendProfileTableViewCell.m
//  Uqrwbearnteyxu
//
//  Created by Developer on 06/01/16.
//  Copyright © 2016 Rahul N. Mane. All rights reserved.
//

#import "FriendProfileTableViewCell.h"

@implementation FriendProfileTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
