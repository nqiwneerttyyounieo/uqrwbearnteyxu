//
//  TabbarViewController.h
//  Uqrwbearnteyxu
//
//  Created by Rahul N. Mane on 05/12/15.
//  Copyright © 2015 Rahul N. Mane. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SlideNavigationController.h"

@interface TabbarViewController : UITabBarController<SlideNavigationControllerDelegate>

@end
