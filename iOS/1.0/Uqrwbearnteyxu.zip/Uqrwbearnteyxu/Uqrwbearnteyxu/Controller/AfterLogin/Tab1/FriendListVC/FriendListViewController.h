//
//  FriendListViewController.h
//  Uqrwbearnteyxu
//
//  Created by Developer on 05/01/16.
//  Copyright © 2016 Rahul N. Mane. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FriendListViewController : UIViewController

@end
